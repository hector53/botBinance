# botBinance

Elaborado con flask de python 

app.py contiene la app de flask 

main.py contiene el bot de binance que funciona como un cron 

datos.py para los datos de conexión 
