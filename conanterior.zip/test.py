import math

montoTransferir =7.99326670
montoTransferir = math.floor(
                    float(montoTransferir) * 1)/1.0
print(montoTransferir)