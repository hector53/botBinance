from flask import Flask
from datos import *
app = Flask(__name__)
app.secret_key = datos["secret_key_login"]

from app.request import *