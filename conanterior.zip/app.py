from flask import Flask, render_template,  request, jsonify,  redirect, url_for, session
import pymysql
from binance.client import Client
from binance.exceptions import BinanceAPIException
from datetime import datetime, date
import math
import json
import collections

from datos import *
# api binance
api_key = datos["api_key"]
api_secret = datos["api_secret"]
# finapibinance

# datos Host para db
host = datos["host"]
database = datos["database"]
userDb = datos["userDb"]
userPass = datos["userPass"]
# datos Host para db

# init binance api
client = Client(api_key, api_secret)

usernameDb = datos["usernameDb"]
passDb = datos["passDb"]

app = Flask(__name__)
app.secret_key = datos["secret_key_login"]




if __name__ == "__main__":
    app.run(debug=True)
