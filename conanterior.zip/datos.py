datos = {
    "host":"localhost",
    "database":"pythontest",
    "userDb" : "root",
    "userPass":"",
    "api_key": "gaszgeLW551gSiwYpqxJCbsdO2bLeD7yXbPIj9avbdM7H1pivsSVr7pPr5SaQz4W", 
    "api_secret": "6SV2XS5aiwWMUZDaj24P7iaAWVJLZOOL3i8jMsYDXlCx0VY7EDrNUbZZJSVf1yx8", 
    "usernameDb": 'hector', 
    "passDb": '123456**', 
    "secret_key_login": '65as4d56as4das651ads86'

}